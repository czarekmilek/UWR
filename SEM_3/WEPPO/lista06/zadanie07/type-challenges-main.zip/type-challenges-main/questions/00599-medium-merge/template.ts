type Merge<F, S> = any
