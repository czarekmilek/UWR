type Enum<T extends readonly string[], N extends boolean = false> = any
