type GetReadonlyKeys<T> = any
