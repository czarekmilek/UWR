type MyExclude<T, U> = any
