type MyOmit<T, K> = any
