type OptionalKeys<T> = any
