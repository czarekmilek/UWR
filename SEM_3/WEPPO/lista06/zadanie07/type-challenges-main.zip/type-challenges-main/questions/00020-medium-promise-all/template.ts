declare function PromiseAll(values: any): any
