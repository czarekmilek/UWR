declare function defineStore(store: unknown): unknown
