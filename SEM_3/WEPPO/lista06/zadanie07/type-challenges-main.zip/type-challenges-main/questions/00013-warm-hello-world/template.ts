type HelloWorld = any // expected to be a string
