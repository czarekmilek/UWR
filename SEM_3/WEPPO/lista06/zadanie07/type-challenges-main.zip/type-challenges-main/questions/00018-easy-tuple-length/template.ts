type Length<T> = any
