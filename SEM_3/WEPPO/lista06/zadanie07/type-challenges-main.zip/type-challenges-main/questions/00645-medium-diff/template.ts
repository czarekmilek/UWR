type Diff<O, O1> = any
