type Concat<T, U> = any
