type UnionToIntersection<U> = any
