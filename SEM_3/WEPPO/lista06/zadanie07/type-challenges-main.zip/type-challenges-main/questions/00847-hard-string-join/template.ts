declare function join(delimiter: any): (...parts: any[]) => any
