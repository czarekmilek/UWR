type StringToUnion<T extends string> = any
