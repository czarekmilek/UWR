type IsUnion<T> = any
