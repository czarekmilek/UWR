type InclusiveRange<Lower extends number, Higher extends number> = any
