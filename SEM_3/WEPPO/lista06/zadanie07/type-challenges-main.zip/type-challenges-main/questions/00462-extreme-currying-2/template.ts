declare function DynamicParamsCurrying(fn: any): any
