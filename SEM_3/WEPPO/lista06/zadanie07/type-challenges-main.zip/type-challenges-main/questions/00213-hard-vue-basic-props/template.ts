declare function VueBasicProps(options: any): any
