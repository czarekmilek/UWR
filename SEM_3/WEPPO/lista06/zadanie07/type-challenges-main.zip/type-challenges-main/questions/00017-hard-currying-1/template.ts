declare function Currying(fn: any): any
