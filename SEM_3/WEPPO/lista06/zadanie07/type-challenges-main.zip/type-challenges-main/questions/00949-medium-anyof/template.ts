type AnyOf<T extends readonly any[]> = any
