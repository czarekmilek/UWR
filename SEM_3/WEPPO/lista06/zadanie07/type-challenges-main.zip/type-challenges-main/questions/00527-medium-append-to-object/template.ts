type AppendToObject<T, U, V> = any
