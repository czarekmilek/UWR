function assertArrayIndex(array: readonly unknown[], key: string) {}

type Index<Array> = any
