type ParseQueryString = any
