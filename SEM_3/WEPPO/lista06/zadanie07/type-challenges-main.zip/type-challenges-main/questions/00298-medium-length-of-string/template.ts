type LengthOfString<S extends string> = any
