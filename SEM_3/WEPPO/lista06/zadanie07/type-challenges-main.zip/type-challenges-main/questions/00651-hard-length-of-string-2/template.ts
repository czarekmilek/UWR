type LengthOfString<S extends string> = number
