type KebabCase<S> = any
