type Chainable = {
  option(key: string, value: any): any
  get(): any
}
