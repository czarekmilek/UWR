type MyReadonly<T> = any
