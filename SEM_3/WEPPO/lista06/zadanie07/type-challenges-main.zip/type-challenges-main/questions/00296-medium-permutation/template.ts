type Permutation<T> = any
