type TrimLeft<S extends string> = any
