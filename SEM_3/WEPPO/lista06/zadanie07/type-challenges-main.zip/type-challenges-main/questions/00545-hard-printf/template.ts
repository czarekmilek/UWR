type Format<T extends string> = any
