public abstract class Expression {
    public abstract int evaluate();
    public abstract String toString();
}
