
public class Sierzant extends StopienWojskowy {
    public Sierzant() {
        super("sierżant");
        ranga = 3;
    }
}