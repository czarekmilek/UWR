public class Szeregowy extends StopienWojskowy {
    public Szeregowy() {
        super("szeregowy");
        ranga = 1;
    }
}