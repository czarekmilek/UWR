

public class Oficer extends StopienWojskowy {
    public Oficer() {
        super("oficer");
        ranga = 4;
    }
}
