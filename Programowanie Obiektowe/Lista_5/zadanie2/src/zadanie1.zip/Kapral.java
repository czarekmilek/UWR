public class Kapral extends StopienWojskowy {
    public Kapral() {
        super("kapral");
        ranga = 2;
    }
}
